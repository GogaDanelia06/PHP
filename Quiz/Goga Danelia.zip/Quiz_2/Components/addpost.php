<div id="addWrap">
    <input type="text" id="BookName" placeholder="BookName" required>
    <input type="number" id="PageNumber" placeholder="PageNumber" required>
    <input type="number" id="Price" placeholder="Price" required>
    <textarea id="BarCode" cols="30" rows="10" placeholder="BarCode" required></textarea>
    <input type="text" id="Author" placeholder="Author" required>
    <button onclick="uploadProduct()">Upload Book</button>
    <span id="addResponse"></span>
</div>