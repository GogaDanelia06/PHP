<div id="addWrap">
    <h1>Log In...</h1>
    <input type="email" id="user_email" placeholder="Email" required>
    <input type="password" id="user_password" placeholder="Password" required>
    <button onclick="logMeIn()">Log In</button>
    <span id="addResponse"></span>
</div>