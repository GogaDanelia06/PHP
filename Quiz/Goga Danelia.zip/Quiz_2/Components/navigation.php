<nav>
    <div onclick="getContent('posts.php')">Books</div>
    <div onclick="getContent('addpost.php')">Add Books</div>
    <div onclick="getContent('login.php')">Log In</div>
    <div onclick="getContent('register.php')">Register</div>
</nav>