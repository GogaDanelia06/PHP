<div id="postWrap">
    <script>
        getPosts();
    </script>
    
</div>