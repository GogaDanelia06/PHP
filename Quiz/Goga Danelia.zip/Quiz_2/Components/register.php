<div id="addWrap">
    <h1>Registration</h1>
    <input type="text" id="user_name" placeholder="Username" required>
    <input type="email" id="user_email" placeholder="Email" required>
    <input type="password" id="user_password" placeholder="Password" required>
    <button onclick="userRegister()">Register</button>
    <span id="addResponse"></span>
</div>